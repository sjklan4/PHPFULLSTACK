<?php
// namespace application\controller;

// class HeaderController extends Controller{ //class스 명을 파일명과 맞춰준다. 
//     public function headerGet(){ // application에서 get을 받아오는 이름을 설정한 것과 같은것을 넣어준다.
//         return "header"._EXTENSION_PHP; //설정한 뷰로 보내는 구문 
//     }

// }

?>
