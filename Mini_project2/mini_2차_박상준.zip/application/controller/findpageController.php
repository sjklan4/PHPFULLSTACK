<?php
namespace application\controller;

class findpageController extends Controller{
    public function findpageGet(){
        return "findpage"._EXTENSION_PHP;
    }

}

?>