<?php
namespace application\controller;

class ApiController extends Controller{ //(3)
    public function userGet(){   //
        $arrGet = $_GET;
        $arrData = [ "flg" => "0"];
        // model 호출
        $this->model = $this->getModel("User"); //model을 지정해서 사용하는 구문(지금은 user모델)

        $result = $this->model->getUser($arrGet, false); // user모델을 getuser로 다시 지정해서 사용
        
        if(count($result) !== 0){
            $arrData["flg"] = "1";
            $arrData["msg"] = "이미 사용 중인 아이디입니다."; 
        } else {
            $arrData["flg"] = "0";
            $arrData["msg"] = "사용 가능한 아이디입니다."; 
        }

        // 배열을 JSON으로 변경
        $json = json_encode($arrData);
        header('Content-type: application/json');
        echo $json;
        exit();
    }


    // public function userdlPost(){   //
    //     $arrGet = $_POST;
    //     $arrData = [ "flg" => "0"];
    //     // model 호출
    //     $this->model = $this->getModel("User"); //model을 지정해서 사용하는 구문(지금은 user모델)

    //     $result = $this->model->getUser($arrGet, false); // user모델을 getuser로 다시 지정해서 사용
        
    //     if(count($result) !== 0){
    //         $arrData["flg"] = "1";
    //         $arrData["msg"] = "확인되었습니다."; 
    //     } else {
    //         $arrData["flg"] = "0";
    //         $arrData["msg"] = "잘못 입력 하였습니다."; 
    //     }

    //     // 배열을 JSON으로 변경
    //     $json = json_encode($arrData);
    //     header('Content-type: application/json');
    //     echo $json;
    //     exit();
    // }

    // public function delPost(){   //
    //     $arrGet = $_POST;
    //     $arrData = [ "flg" => "0"];
    //     // model 호출
    //     $this->model = $this->getModel("User"); //model을 지정해서 사용하는 구문(지금은 user모델)

    //     $result = $this->model->getUser($arrGet); // user모델을 getuser로 다시 지정해서 사용
        
    //     if(count($result) !== 0){
    //         $arrData["flg"] = "1";
    //         $arrData["msg"] = "비밀 번호가 일치하지 않습니다."; 
    //     } 

    //     // 배열을 JSON으로 변경
    //     $json = json_encode($arrData);
    //     header('Content-type: application/json');
    //     echo $json;
    //     exit();
    // }
    // public function delPost(){
    //     $id = [ "u_id" => $_SESSION[_STR_LOGIN_ID]];
    //     $result = $this->model->deletemember($id,false);
    //     // $this->addDynamicProperty("userInfo",$result[0]); 
    //     $this->model->beginTransaction();
    //     $this->model->commit();
    //     session_unset();
    //     session_destroy();

    //     return "main"._EXTENSION_PHP;

    //     $json = json_encode($arrData);
    //     header('Content-type: application/json');
    //     echo $json;
    //     exit();
    // }

    
}

?>