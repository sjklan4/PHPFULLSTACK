<?php
namespace application\controller;

class ProductController extends Controller{
    public function listGet(){
        return "list"._EXTENSION_PHP;
    }

}

?>