<?php

namespace application\model;

class ApiModel extends Model {
    
}


?>