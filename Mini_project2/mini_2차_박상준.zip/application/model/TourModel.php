<?php

namespace application\model;

class TourModel extends Model {
    public function mainGet(){
        return "main"._EXTENSION_PHP;
    }
}


?>