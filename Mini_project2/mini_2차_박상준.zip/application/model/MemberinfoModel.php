<?php

namespace application\model;

class MemberinfoModel extends Model {
    
}


?>