<?php

namespace application\model;

class ProductModel extends Model {
    
}


?>